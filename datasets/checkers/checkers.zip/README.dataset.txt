# Train > 2022-11-08 10:43pm
https://universe.roboflow.com/object-detection/train-gid0o

Provided by a Roboflow user
License: CC BY 4.0

